#pragma once

#include <stdint.h>
#include <string>
using namespace std;

typedef bool    boolean;
typedef string  String;
